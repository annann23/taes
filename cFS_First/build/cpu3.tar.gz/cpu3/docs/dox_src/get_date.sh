export CURR_DATE=`date +%x`
